const assessment = [
    {
        "question": "What is a question?",
        "type":"multiple_choice",
        "options":["a", "b", "c", "d"],
        "answer": ["a"],
    },
    {
        "question": "This is a question",
        "type":"true_false",
        "answer": ["false"],
    },
    {
        "question": "What is a question?",
        "type": "fill_in",
        "answer": ["42"],
    }
]