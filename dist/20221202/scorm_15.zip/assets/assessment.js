const assessment = [
    {
        "question": "What is a question?",
        "type":"choice",
        "options":["a", "b", "c", "d"],
        "answer": ["a"],
    },
    {
        "question": "This is a question",
        "type":"true-false",
        "answer": ["false"],
    },
    {
        "question": "What is a question?",
        "type": "fill-in",
        "answer": ["42"],
    }
]